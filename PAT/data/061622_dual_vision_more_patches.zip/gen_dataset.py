import numpy as np
import cv2
import os

def print_stat(narray, narray_name = 'Array'):
    print(narray_name + " stat: shape: {}, dtype: {}".format(narray.shape, narray.dtype))
    arr = narray.flatten()
    print("max: {}, min: {}, mean: {}, std: {}".format(arr.max(), arr.min(), arr.mean(), arr.std()))

res_w1, res_h1 = 4024, 3036
res_w2, res_h2 = 4912, 3684
F = np.array([[3.61267656798871e-09,	3.03286396787507e-07,	-0.00145439021009031],
[-4.06053956369527e-07,	2.04760848754980e-08,	0.0202623801005043],
[0.00103349357679728,	-0.00677562855132053,	-23.3433435488500]])

image_coor = np.meshgrid(np.arange(res_h1), np.arange(res_w1))
cam_coor = np.stack([image_coor[1].T,
                     image_coor[0].T,
                     np.ones_like(image_coor[1].T)], axis=2)
image_coor2 = np.meshgrid(np.arange(res_h2), np.arange(res_w2))
cam_coor2 = np.stack([image_coor2[1].T,
                      image_coor2[0].T,
                      np.ones_like(image_coor2[1].T)], axis=2)


# img1 = cv2.imread('allied_2.png', 0)
# img2 = cv2.imread('ids_2.png')

# print(img1.shape, img2.shape)

for i in range(132):
    for j in range(8):
        ID = i*8+j+1
        print(ID)
        xl, xu, yl, yu = i*23, i*23+23, j*503, j*503+503
        xxss = []
        yyss = []
        for point_x in range(xl, xu):
            for point_y in range(yl, yu):
                lam = F.dot(np.array([point_y, point_x, 1]).reshape((-1, 3)).T)
                x_ub = min(int(point_x*0.3 + 90), 1000)
                x_lb = x_ub - 80
                y_lb = max(int(point_y*0.33-40),0)
                y_ub = y_lb + 80
                dist = np.abs(cam_coor2[1250:2250, 2100:3500][x_lb:x_ub, y_lb:y_ub].reshape((-1, 3)).dot(lam))
                n = 80
                pps = np.argpartition(dist, n, axis=0)[:n].T
                xxs, yys = pps//n + x_lb, pps%n+y_lb
                xxss.append(xxs[0])
                yyss.append(yys[0])
                
        xxss = np.stack(xxss, axis=0).astype(np.int16)
        yyss = np.stack(yyss, axis=0).astype(np.int16)

        np.save('xxs_{:04d}.npy'.format(ID), xxss)
        np.save('yys_{:04d}.npy'.format(ID), yyss)
        
        # os.system('ln -s xxs_{:04d}.npy xxs_{:04d}.npy'.format((ID-1)%48+1, ID))
        # os.system('ln -s yys_{:04d}.npy yys_{:04d}.npy'.format((ID-1)%48+1, ID))
        
        # if not os.path.exists('hr/{:04d}'.format(ID)):
        #     os.makedirs('hr/{:04d}'.format(ID))
        # cv2.imwrite('hr/{:04d}/hr0.png'.format(ID), img1[xl:xu, yl:yu])
        # cv2.imwrite('hr/{:04d}/hr1.png'.format(ID), img2[1250:2250, 2100:3500])
